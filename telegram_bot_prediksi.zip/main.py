from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
import os

def hitung_prediksi(data):
    odd_even = ["Odd" if int(x) % 2 == 1 else "Even" for x in data]
    if odd_even.count("Odd") > odd_even.count("Even"):
        return "Prediksi: Even"
    else:
        return "Prediksi: Odd"

async def prediksi(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        angka = [int(x) for x in context.args]
        if len(angka) < 3:
            await update.message.reply_text("Kirim minimal 3 angka, misalnya: /prediksi 26 45 80")
            return
        hasil = hitung_prediksi(angka[-3:])
        await update.message.reply_text(hasil)
    except Exception:
        await update.message.reply_text("Format salah. Kirim angka seperti: /prediksi 26 45 80")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Halo! Kirim /prediksi 26 45 80 untuk mulai.")

async def main():
    app = ApplicationBuilder().token(os.getenv("BOT_TOKEN")).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("prediksi", prediksi))
    await app.run_polling()

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
